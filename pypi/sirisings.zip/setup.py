from setuptools import setup

setup(
    name='sirisings',
    version='0.1',
    url='https://sosheskaz.github.io/project-awful/',
    author='Eric Miller',
    licents='GPLv3+'
    install_requires=[
        'PyLyrics>=1.1,<1.2',
        'Google-Search-API>=1.0,<2.0'
    ],
    scripts=[
        'sirisings/sirisings.py'
    ]
)
